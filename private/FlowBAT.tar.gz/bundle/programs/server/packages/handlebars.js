(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.handlebars = {};

})();

//# sourceMappingURL=handlebars.js.map
