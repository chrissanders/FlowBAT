(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
i18n.init({
  resStore: {},
  fallbackLng: "en",
  interpolationPrefix: "{{",
  interpolationSuffix: "}}"
});

})();

//# sourceMappingURL=_.coffee.js.map
