(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;


})();

//# sourceMappingURL=users.hooks.coffee.js.map
