(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.Emails = new Meteor.Collection("emails");

share.Queries = new Meteor.Collection("queries");

share.IPSets = new Meteor.Collection("ipsets");

share.Tuples = new Meteor.Collection("tuples");

share.Configs = new Meteor.Collection("configs");

})();

//# sourceMappingURL=collections.coffee.js.map
